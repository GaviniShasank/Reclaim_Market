const newProduct=(req,res)=>{

}
const dltProduct=(req,res)=>{
    
}
const modifyProduct=(req,res)=>{
    
}
const sortinorder=(req,res)=>{

}


module.exports = {
    newProduct,
    dltProduct,
    modifyProduct
  
}